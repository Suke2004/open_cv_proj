# Arduino
This hardware project is based on using: OV7670 Camera Module with Arduino UNO to capture images of packages, items and fruits and storing them in a folder . 
